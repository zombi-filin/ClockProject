#include <stm32f1xx_hal.h>
#include <stm32_hal_legacy.h>
#include <stm32f1xx_hal_i2c.h>
#include <stdio.h>


#ifdef __cplusplus
extern "C"
#endif
void SysTick_Handler(void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
}

int encodeMinSec(uint8_t value)
{
	return (int)((value / 16 * 10) + (value % 16));
}

int encodeHour(uint8_t value)
{
	uint8_t h10 = (value >> 4) & 1;
	uint8_t h20 = (value >> 5) & 1;
	return (int)(h20*20 + h10*10 + (value % 16));
}

int main(void)
{
	HAL_Init();

	// init I2C 
	//
	__GPIOB_CLK_ENABLE();
	
	GPIO_InitTypeDef GPIO_InitStruct;
 
	GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	//
	__I2C1_CLK_ENABLE();
	
	I2C_HandleTypeDef hI2C = I2C_HandleTypeDef();
 
	hI2C.Instance = I2C1;
	hI2C.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hI2C.Init.ClockSpeed = 10240;
	hI2C.Init.DutyCycle = I2C_DUTYCYCLE_2;
 
 
	if (HAL_I2C_Init(&hI2C) != HAL_OK)
		asm("bkpt 255");
	
	
	uint16_t devAddr = 0xd0;
	
	/**/
	while (1)
	{
		uint8_t time[3];
		if (HAL_I2C_Mem_Read(&hI2C, devAddr, 0x00, I2C_MEMADD_SIZE_8BIT, time, 3, 100) != HAL_OK) printf("ERROR get time\n");
		printf("%02d:%02d:%02d\n", encodeHour(time[2]), encodeMinSec(time[1]), encodeMinSec(time[0]));
		HAL_Delay(500);
		
	}
	/**/
	
	/*
	// Scan I2C devices
	for (uint8_t i = 0; i < 255; i++)
	{
		uint8_t result[7];
		if (HAL_I2C_Mem_Read(&hI2C, i, 0x00, I2C_MEMADD_SIZE_8BIT, result, 1, 100) == HAL_OK) {
			printf("find: 0x%02x \n", i);
		};
	}
	printf("complite\n");
	/**/
}